/*
 An enum that takes on one of four types, always returning
* one of the four listed below for the deck of cards
 */
package outlabonev;

/**
 *
 * @author josiah
 */
//Enum class for all the suits possible for a card
public enum Suit {
    Clubs,
    Diamonds,
    Spades,
    Hearts,
    
    
}
